
export interface User {
  id: string;
  username: string;
  email?: string;
  phone?: string;
  avatarUrl: string;
  bio?: string;
  blazeScore: number;
  onlineStatus: boolean;
  friends: string[]; // array of user IDs
  friendRequests: string[]; // array of user IDs
}

export type MediaFilter = 'none' | 'grayscale' | 'blur' | 'brightness';

export interface MediaItem {
  id: string;
  type: 'photo' | 'video';
  url: string; // For videos, could be a blob URL, for photos base64 or blob
  filter?: MediaFilter;
  textOverlay?: string;
  emojiOverlay?: string; // Could be a specific emoji character or ID
}

export interface CapturedMedia extends MediaItem {
  // Any specific props for media right after capture
}

export interface Message {
  id:string;
  chatId: string;
  senderId: string;
  receiverId: string; // For direct messages if applicable in a group chat context
  content: string | MediaItem; // Text or media
  timestamp: number;
  seen: boolean;
  disappears: boolean; // True for photos/videos/voice notes after view
  isVoiceNote?: boolean;
}

export interface Chat {
  id: string;
  participants: User[]; // Simplified to User objects
  messages: Message[];
  blazeStreak: number;
  lastMessage?: Message; // For display on chat list
  typingUserIds?: string[]; // IDs of users currently typing
}

export interface Story {
  id: string;
  userId: string;
  userAvatar: string;
  username: string;
  media: MediaItem[]; // A story can have multiple segments
  timestamp: number;
  expiresAt: number;
  viewers: string[]; // List of user IDs who viewed
}

export interface VaultItem {
  id: string;
  media: MediaItem;
  sharedBy: string; // User ID
  savedAt: number;
  isMutualSave: boolean; // True if both sender and receiver saved
}

export enum AppScreen {
  SPLASH = 'SPLASH',
  AUTH = 'AUTH',
  CAMERA = 'CAMERA',
  FRIENDS = 'FRIENDS', // Will also list chats
  STORIES = 'STORIES',
  VAULT = 'VAULT',
  PROFILE = 'PROFILE',
  CHAT_DETAIL = 'CHAT_DETAIL',
  MEDIA_PREVIEW = 'MEDIA_PREVIEW',
  SEND_TO = 'SEND_TO',
}

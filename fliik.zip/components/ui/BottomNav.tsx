
import React from 'react';
import { AppScreen } from '../../types';
import { CameraIcon, UsersIcon, StoryIcon, LockClosedIcon, UserCircleIcon, ICON_SIZE } from '../../constants';

interface BottomNavProps {
  activeScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
}

const navItems = [
  { screen: AppScreen.CAMERA, icon: CameraIcon, label: 'Camera' },
  { screen: AppScreen.FRIENDS, icon: UsersIcon, label: 'Friends' },
  { screen: AppScreen.STORIES, icon: StoryIcon, label: 'Stories' },
  { screen: AppScreen.VAULT, icon: LockClosedIcon, label: 'Vault' },
  { screen: AppScreen.PROFILE, icon: UserCircleIcon, label: 'Profile' },
];

export const BottomNav: React.FC<BottomNavProps> = ({ activeScreen, onNavigate }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 h-20 bg-black/80 backdrop-blur-md border-t border-white/20 flex justify-around items-center z-40">
      {navItems.map((item) => {
        const isActive = activeScreen === item.screen;
        const IconComponent = item.icon;
        return (
          <button
            key={item.screen}
            onClick={() => onNavigate(item.screen)}
            className={`flex flex-col items-center justify-center p-2 rounded-lg transition-all duration-200 ease-in-out transform hover:scale-110 focus:outline-none ${
              isActive ? 'text-pink-400' : 'text-gray-400 hover:text-white'
            }`}
            aria-label={item.label}
          >
            <IconComponent className={`${ICON_SIZE} ${isActive ? 'fill-pink-400 stroke-pink-500' : ''}`} />
            <span className={`mt-1 text-xs ${isActive ? 'font-semibold' : ''}`}>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};

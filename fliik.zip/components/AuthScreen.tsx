
import React, { useState } from 'react';
import { User } from '../../types';
import { APP_NAME, MOCK_USERS } from '../../constants';
import { Button } from './ui/Button';
import { Input } from './ui/Input';

interface AuthScreenProps {
  onLogin: (user: User) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLogin, setIsLogin] = useState(true); // Toggle between Login and Signup

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you'd call an auth service here.
    // For this mock, we'll just log in the first mock user.
    console.log(`${isLogin ? 'Logging in' : 'Signing up'} with:`, { email, password });
    onLogin(MOCK_USERS[0]); 
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-purple-900 to-teal-900 p-4 text-white">
      <div className="w-full max-w-md p-8 bg-black/50 backdrop-blur-lg rounded-2xl shadow-2xl border border-white/10">
        <h1 className="text-5xl font-bold text-center mb-4" style={{ fontFamily: "'Pacifico', cursive" }}>{APP_NAME}</h1>
        <h2 className="text-2xl font-semibold text-center mb-8 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-teal-400">
          {isLogin ? 'Welcome Back!' : 'Create Account'}
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <Input
            label="Email"
            type="email"
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
          />
          <Input
            label="Password"
            type="password"
            name="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            required
          />
          {!isLogin && (
            <Input
              label="Confirm Password"
              type="password"
              name="confirmPassword"
              placeholder="••••••••"
              required
            />
          )}
          <Button type="submit" fullWidth size="lg">
            {isLogin ? 'Login' : 'Sign Up'}
          </Button>
        </form>

        <div className="mt-8 text-center">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-sm text-pink-400 hover:text-pink-300 hover:underline"
          >
            {isLogin ? "Don't have an account? Sign Up" : 'Already have an account? Login'}
          </button>
        </div>

        <div className="mt-6 flex items-center justify-center">
            <span className="h-px w-full bg-gray-700"></span>
            <span className="px-3 text-gray-500">OR</span>
            <span className="h-px w-full bg-gray-700"></span>
        </div>
        
        <div className="mt-6 space-y-3">
            <Button variant="secondary" fullWidth onClick={() => onLogin(MOCK_USERS[0])}> {/* Mock Google/Phone login */}
                Continue with Google
            </Button>
            <Button variant="secondary" fullWidth onClick={() => onLogin(MOCK_USERS[0])}>
                Continue with Phone
            </Button>
        </div>
      </div>
    </div>
  );
};

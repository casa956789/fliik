
import React, { useState } from 'react';
import { Story, User, AppScreen, MediaItem } from '../../types';
import { MOCK_STORIES, PlusCircleIcon, DEFAULT_AVATAR } from '../../constants';
import { Modal } from './ui/Modal';
import { Button } from './ui/Button';

interface StoriesViewProps {
  currentUser: User;
  onViewStory: (story: Story) => void;
  onNavigate: (screen: AppScreen) => void;
}

const StoryCircle: React.FC<{ story?: Story; isMyStory?: boolean; user?: User; onClick: () => void; hasViewedAll?: boolean }> = ({ story, isMyStory, user, onClick, hasViewedAll }) => {
  const avatarUrl = story?.userAvatar || user?.avatarUrl || DEFAULT_AVATAR;
  const username = story?.username || user?.username || "My Story";
  const ringColor = hasViewedAll ? 'border-gray-600' : 'border-pink-500 hover:border-teal-400';

  return (
    <div className="flex flex-col items-center cursor-pointer w-24" onClick={onClick}>
      <div className={`w-20 h-20 rounded-full border-4 ${ringColor} p-0.5 flex items-center justify-center transition-all duration-200`}>
        <img src={avatarUrl} alt={username} className="w-full h-full rounded-full object-cover" />
      </div>
      <p className="mt-2 text-xs text-center text-gray-300 truncate w-full">{username}</p>
    </div>
  );
};

export const StoryViewerModal: React.FC<{ story: Story; onClose: () => void; currentUser: User }> = ({ story, onClose, currentUser }) => {
    const [currentSegmentIndex, setCurrentSegmentIndex] = useState(0);
    const [isPaused, setIsPaused] = useState(false);
    
    // Auto-advance logic (simplified)
    React.useEffect(() => {
        if (isPaused || story.media.length <=1 ) return;
        const timer = setTimeout(() => {
            if (currentSegmentIndex < story.media.length - 1) {
                setCurrentSegmentIndex(prev => prev + 1);
            } else {
                onClose(); // Close when all segments are viewed
            }
        }, 5000); // 5 seconds per segment
        return () => clearTimeout(timer);
    }, [currentSegmentIndex, story.media.length, onClose, isPaused]);

    const currentMedia = story.media[currentSegmentIndex];

    const handleTap = (e: React.MouseEvent<HTMLDivElement>) => {
        const { clientX, currentTarget } = e;
        const { offsetWidth } = currentTarget;
        if (clientX < offsetWidth / 3) { // Tap left
            setCurrentSegmentIndex(prev => Math.max(0, prev - 1));
        } else { // Tap right or center
            if (currentSegmentIndex < story.media.length - 1) {
                setCurrentSegmentIndex(prev => prev + 1);
            } else {
                onClose();
            }
        }
    };
    
    return (
        <Modal isOpen={true} onClose={onClose} size="full">
            <div className="h-full w-full bg-black flex flex-col relative" 
                 onMouseDown={() => setIsPaused(true)} 
                 onMouseUp={() => setIsPaused(false)}
                 onTouchStart={() => setIsPaused(true)}
                 onTouchEnd={() => setIsPaused(false)}
                 onClick={handleTap}
            >
                {/* Progress bars */}
                <div className="absolute top-2 left-2 right-2 flex space-x-1 z-10">
                    {story.media.map((_, index) => (
                        <div key={index} className="flex-1 h-1 bg-white/30 rounded-full">
                            <div 
                                className={`h-full rounded-full ${index < currentSegmentIndex ? 'bg-white' : index === currentSegmentIndex ? 'bg-white animate-progress' : 'bg-transparent'}`}
                                style={{animationDuration: isPaused ? '0s' : '5s'}}
                            />
                        </div>
                    ))}
                </div>

                <div className="absolute top-10 left-2 flex items-center z-10 p-2 bg-black/30 rounded-lg">
                    <img src={story.userAvatar} alt={story.username} className="w-8 h-8 rounded-full mr-2"/>
                    <span className="text-white font-semibold">{story.username}</span>
                    <span className="text-gray-400 text-sm ml-2">{new Date(story.timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
                </div>
                
                <button onClick={onClose} className="absolute top-4 right-4 text-white z-20 p-2 bg-black/30 rounded-full">
                    <PlusCircleIcon className="w-6 h-6 rotate-45 transform"/>
                </button>

                {currentMedia.type === 'photo' ? (
                    <img src={currentMedia.url} alt="Story content" className="w-full h-full object-contain" />
                ) : (
                    <video src={currentMedia.url} autoPlay controls={false} className="w-full h-full object-contain"></video>
                )}
                {currentMedia.textOverlay && (
                    <div className="absolute bottom-20 left-0 right-0 p-4 text-center">
                        <p className="text-white text-2xl font-bold" style={{textShadow: '2px 2px 4px rgba(0,0,0,0.7)'}}>{currentMedia.textOverlay}</p>
                    </div>
                )}
                {story.userId !== currentUser.id && (
                     <div className="absolute bottom-4 left-4 right-4 z-10">
                        <input type="text" placeholder={`Reply to ${story.username}...`} className="w-full p-3 rounded-full bg-black/50 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-500" />
                    </div>
                )}
            </div>
             <style>{`
                @keyframes progressFill {
                    from { width: 0%; }
                    to { width: 100%; }
                }
                .animate-progress { animation: progressFill linear; }
            `}</style>
        </Modal>
    );
};


export const StoriesView: React.FC<StoriesViewProps> = ({ currentUser, onNavigate }) => {
  const [stories, setStories] = useState<Story[]>(MOCK_STORIES.filter(s => s.expiresAt > Date.now()));
  const [viewingStory, setViewingStory] = useState<Story | null>(null);
  
  // Mock: Track viewed stories (very simplified)
  const [viewedStoryIds, setViewedStoryIds] = useState<Set<string>>(new Set());

  const handleViewStory = (story: Story) => {
    setViewingStory(story);
    setViewedStoryIds(prev => new Set(prev).add(story.id)); // Mark as "attempted to view"
  };

  const handleCloseStoryViewer = () => {
    setViewingStory(null);
  };
  
  const friendsWithStories = stories.filter(s => s.userId !== currentUser.id);
  const myStory = stories.find(s => s.userId === currentUser.id);


  return (
    <div className="h-full flex flex-col bg-gray-900 text-white p-4 pt-10 pb-20">
      <header className="mb-6 flex justify-between items-center">
        <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-teal-400">Fliiks</h1>
        {/* Placeholder for settings or search */}
      </header>

      <div className="flex space-x-4 overflow-x-auto pb-4 scrollbar-thin scrollbar-thumb-purple-500/50 scrollbar-track-gray-800/50">
        <StoryCircle 
            isMyStory 
            user={currentUser} 
            onClick={() => {
                if(myStory) handleViewStory(myStory)
                else onNavigate(AppScreen.CAMERA) // Navigate to camera to create story
            }}
            hasViewedAll={myStory ? viewedStoryIds.has(myStory.id) : true} // If no story, it's "viewed"
        />
        {friendsWithStories.map(story => (
          <StoryCircle key={story.id} story={story} onClick={() => handleViewStory(story)} hasViewedAll={viewedStoryIds.has(story.id)} />
        ))}
      </div>
      
      <div className="mt-6 text-center">
        <p className="text-gray-500">Stories disappear after 24 hours.</p>
        <Button onClick={() => onNavigate(AppScreen.CAMERA)} className="mt-4" leftIcon={<PlusCircleIcon className="w-5 h-5"/>}>
            Add to Your Story
        </Button>
      </div>

      {viewingStory && (
        <StoryViewerModal story={viewingStory} onClose={handleCloseStoryViewer} currentUser={currentUser} />
      )}
    </div>
  );
};


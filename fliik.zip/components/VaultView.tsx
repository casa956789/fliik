
import React, { useState, useEffect } from 'react';
import { User, VaultItem, MediaItem } from '../../types';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Modal } from './ui/Modal';
import { LockClosedIcon, DEFAULT_AVATAR } from '../../constants';

interface VaultViewProps {
  currentUser: User;
}

const MOCK_VAULT_PIN = "1234"; // In a real app, this would be securely stored / handled

const MOCK_VAULT_ITEMS: VaultItem[] = [
    { id: 'vault1', media: { id: 'vmedia1', type: 'photo', url: 'https://picsum.photos/seed/vault1/400/600' }, sharedBy: 'user2', savedAt: Date.now() - 86400000 * 2, isMutualSave: true},
    { id: 'vault2', media: { id: 'vmedia2', type: 'video', url: 'https://picsum.photos/seed/vault2/400/600' }, sharedBy: 'user1', savedAt: Date.now() - 86400000 * 5, isMutualSave: false},
    { id: 'vault3', media: { id: 'vmedia3', type: 'photo', url: 'https://picsum.photos/seed/vault3/400/600' }, sharedBy: 'user3', savedAt: Date.now() - 86400000 * 1, isMutualSave: true},
];


export const VaultView: React.FC<VaultViewProps> = ({ currentUser }) => {
  const [isLocked, setIsLocked] = useState(true);
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [vaultItems, setVaultItems] = useState<VaultItem[]>([]);
  const [showPinModal, setShowPinModal] = useState(true); // Initially show PIN modal if locked

  useEffect(() => {
    if (!isLocked) {
      // Filter items: show own saves and mutual saves
      const userVaultItems = MOCK_VAULT_ITEMS.filter(item => item.sharedBy === currentUser.id || item.isMutualSave);
      setVaultItems(userVaultItems);
      setShowPinModal(false);
    } else {
      setVaultItems([]);
      setShowPinModal(true);
    }
  }, [isLocked, currentUser.id]);

  const handlePinSubmit = () => {
    if (pin === MOCK_VAULT_PIN) {
      setIsLocked(false);
      setError('');
      setPin('');
    } else {
      setError('Incorrect PIN. Try again.');
      setPin('');
    }
  };

  const handleLockVault = () => {
    setIsLocked(true);
    setPin(''); // Clear PIN when locking
  }

  if (isLocked) {
    return (
      <Modal isOpen={showPinModal} onClose={() => { /* Cannot close if locked */ }} title="Vault Locked">
        <div className="flex flex-col items-center text-center p-4">
          <LockClosedIcon className="w-16 h-16 text-pink-400 mb-4" />
          <p className="mb-4 text-gray-300">Enter your 4-digit PIN to access your Vault.</p>
          <Input
            type="password" // Use password type to hide PIN
            value={pin}
            onChange={(e) => {
                if (e.target.value.length <= 4 && /^\d*$/.test(e.target.value)) {
                    setPin(e.target.value)
                }
            }}
            maxLength={4}
            placeholder="••••"
            className="text-center text-2xl tracking-[0.5em] w-40 mb-2"
          />
          {error && <p className="text-red-400 text-sm mb-2">{error}</p>}
          <Button onClick={handlePinSubmit} fullWidth disabled={pin.length !== 4}>Unlock</Button>
           <p className="text-xs text-gray-500 mt-4">Demo PIN: {MOCK_VAULT_PIN}</p>
        </div>
      </Modal>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gray-900 text-white p-4 pt-10 pb-20">
      <header className="mb-6 flex justify-between items-center">
        <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-teal-400">Vault</h1>
        <Button onClick={handleLockVault} variant="secondary" size="sm" leftIcon={<LockClosedIcon className="w-4 h-4"/>}>Lock Vault</Button>
      </header>

      {vaultItems.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center">
            <LockClosedIcon className="w-20 h-20 text-gray-600 mb-4"/>
            <p className="text-gray-500 text-lg">Your Vault is empty.</p>
            <p className="text-gray-600 text-sm">Saved Fliiks from you and your friends (if mutually saved) will appear here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 sm:gap-4 overflow-y-auto">
          {vaultItems.map(item => (
            <div key={item.id} className="aspect-square rounded-lg overflow-hidden relative group border-2 border-transparent hover:border-pink-500 transition-all">
              {item.media.type === 'photo' ? (
                <img src={item.media.url} alt="Vaulted media" className="w-full h-full object-cover" />
              ) : (
                <video src={item.media.url} className="w-full h-full object-cover" loop muted playsInline />
              )}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-2">
                <p className="text-xs text-white text-center">Saved: {new Date(item.savedAt).toLocaleDateString()}</p>
                {item.isMutualSave && <p className="text-xs text-teal-300 font-semibold">Mutual!</p>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};


import React, { useState } from 'react';
import { User, AppScreen } from '../../types';
import { Button } from './ui/Button';
import { DEFAULT_AVATAR, FireIcon, LockClosedIcon, LogoutIcon, SparklesIcon, EyeIcon } from '../../constants';
import { Modal } from './ui/Modal';
import { Input } from './ui/Input';

interface ProfileViewProps {
  currentUser: User;
  onLogout: () => void;
  onNavigate: (screen: AppScreen) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ currentUser, onLogout, onNavigate }) => {
  const [isEditingBio, setIsEditingBio] = useState(false);
  const [bio, setBio] = useState(currentUser.bio || '');
  const [onlineVisibility, setOnlineVisibility] = useState(currentUser.onlineStatus);

  const handleSaveBio = () => {
    // Mock save bio: in real app, call API
    currentUser.bio = bio;
    setIsEditingBio(false);
    alert("Bio updated (mocked)!");
  };

  const blazeLevelPercentage = Math.min(100, (currentUser.blazeScore / 5000) * 100); // Max score for 100% is 5000

  return (
    <div className="h-full flex flex-col bg-gray-900 text-white p-4 pt-10 pb-20 overflow-y-auto">
      <header className="text-center mb-8">
        <div className="relative w-32 h-32 mx-auto mb-4">
            <img 
                src={currentUser.avatarUrl || DEFAULT_AVATAR} 
                alt={currentUser.username} 
                className="w-full h-full rounded-full object-cover border-4 border-pink-500 shadow-lg"
            />
            <button className="absolute bottom-0 right-0 bg-purple-500 p-2 rounded-full border-2 border-gray-900 hover:bg-purple-600 transition-colors">
                <SparklesIcon className="w-5 h-5 text-white"/> {/* Change avatar icon */}
            </button>
        </div>
        <h1 className="text-3xl font-bold">{currentUser.username}</h1>
        {isEditingBio ? (
            <div className="mt-2 flex flex-col items-center">
                <Input 
                    type="text" 
                    value={bio} 
                    onChange={(e) => setBio(e.target.value)} 
                    placeholder="Your awesome bio..."
                    className="w-full max-w-sm text-center bg-gray-800"
                />
                <Button onClick={handleSaveBio} size="sm" className="mt-2">Save Bio</Button>
            </div>
        ) : (
            <p className="text-gray-400 mt-1 cursor-pointer hover:text-pink-400" onClick={() => setIsEditingBio(true)}>
                {currentUser.bio || "Tap to add a bio"}
            </p>
        )}
      </header>

      <div className="mb-8 p-6 bg-gray-800/50 rounded-xl border border-white/10 backdrop-blur-md">
        <div className="flex items-center justify-between mb-3">
            <h2 className="text-xl font-semibold text-pink-400">Blaze 🔥</h2>
            <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-orange-400 to-red-500">{currentUser.blazeScore}</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2.5">
            <div 
                className="bg-gradient-to-r from-orange-500 to-red-600 h-2.5 rounded-full transition-all duration-500 ease-out" 
                style={{ width: `${blazeLevelPercentage}%` }}
            ></div>
        </div>
        <p className="text-xs text-gray-500 mt-1 text-right">Level {Math.floor(blazeLevelPercentage/10)}</p>
      </div>

      <div className="space-y-3">
        <ProfileButton icon={<LockClosedIcon className="w-5 h-5"/>} text="My Vault" onClick={() => onNavigate(AppScreen.VAULT)} />
        <ProfileButton icon={<EyeIcon className="w-5 h-5"/>} text={`Online Visibility: ${onlineVisibility ? 'On' : 'Off'}`} onClick={() => setOnlineVisibility(!onlineVisibility)} isToggle={true} isActive={onlineVisibility} />
        {/* Add more settings here */}
        <ProfileButton icon={<SparklesIcon className="w-5 h-5"/>} text="Story Customization" onClick={() => alert("Story settings (mocked)")} />
      </div>

      <div className="mt-auto pt-8">
        <Button onClick={onLogout} fullWidth variant="danger" leftIcon={<LogoutIcon className="w-5 h-5"/>}>
          Log Out
        </Button>
      </div>
    </div>
  );
};

interface ProfileButtonProps {
    icon: React.ReactNode;
    text: string;
    onClick: () => void;
    isToggle?: boolean;
    isActive?: boolean;
}

const ProfileButton: React.FC<ProfileButtonProps> = ({ icon, text, onClick, isToggle, isActive }) => {
    return (
        <button 
            onClick={onClick}
            className="w-full flex items-center justify-between p-4 bg-gray-800/60 hover:bg-gray-700/80 rounded-lg transition-colors duration-150 border border-transparent hover:border-pink-500/30"
        >
            <div className="flex items-center">
                <span className="mr-3 text-pink-400">{icon}</span>
                <span className="text-white">{text}</span>
            </div>
            {isToggle ? (
                <div className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer ${isActive ? 'bg-teal-500' : 'bg-gray-600'}`}>
                    <div className={`bg-white w-4 h-4 rounded-full shadow-md transform duration-300 ease-in-out ${isActive ? 'translate-x-6' : ''}`}></div>
                </div>
            ) : (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-gray-500">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
            )}
        </button>
    )
}

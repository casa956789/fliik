
import React, { useState } from 'react';
import { User, Chat, AppScreen } from '../../types';
import { MOCK_USERS, MOCK_CHATS, FireIcon, PlusCircleIcon, ChatBubbleLeftRightIcon, DEFAULT_AVATAR } from '../../constants';
import { Input } from './ui/Input';
import { Button } from './ui/Button';
import { Modal } from './ui/Modal';

interface FriendsViewProps {
  currentUser: User;
  onNavigate: (screen: AppScreen, params?: any) => void; // params for chatID
}

const FriendCard: React.FC<{user: User, onChat: () => void, blazeScore?: number}> = ({ user, onChat, blazeScore }) => (
    <div 
        onClick={onChat}
        className="flex items-center p-3 bg-gray-800/50 hover:bg-gray-700/70 rounded-lg cursor-pointer transition-all duration-150 mb-2 border border-transparent hover:border-pink-500/50"
    >
        <img src={user.avatarUrl || DEFAULT_AVATAR} alt={user.username} className="w-12 h-12 rounded-full mr-4 border-2 border-purple-500"/>
        <div className="flex-1">
            <h4 className="font-semibold text-lg text-white">{user.username}</h4>
            <p className="text-sm text-gray-400">Tap to chat</p>
        </div>
        {blazeScore && (
            <div className="flex items-center text-orange-400">
                <FireIcon className="w-5 h-5 mr-1"/>
                <span className="font-bold">{blazeScore}</span>
            </div>
        )}
    </div>
);

const ChatListItem: React.FC<{chat: Chat, currentUser: User, onOpenChat: (chatId: string) => void}> = ({ chat, currentUser, onOpenChat }) => {
    const otherParticipant = chat.participants.find(p => p.id !== currentUser.id) || chat.participants[0];
    const lastMessageText = typeof chat.lastMessage?.content === 'string' ? chat.lastMessage.content : (chat.lastMessage?.content as any)?.type === 'photo' ? '📷 Photo' : (chat.lastMessage?.content as any)?.type === 'video' ? '📹 Video' : 'New Fliik!';
    
    return (
        <div 
            onClick={() => onOpenChat(chat.id)}
            className="flex items-center p-4 bg-gray-800/60 hover:bg-gray-700/80 rounded-xl cursor-pointer transition-all duration-150 mb-3 border border-white/10 backdrop-blur-sm shadow-lg"
        >
            <img src={otherParticipant.avatarUrl || DEFAULT_AVATAR} alt={otherParticipant.username} className="w-14 h-14 rounded-full mr-4 border-2 border-teal-400 object-cover"/>
            <div className="flex-1">
                <div className="flex justify-between items-center">
                    <h4 className="font-semibold text-lg text-white">{otherParticipant.username}</h4>
                    {chat.blazeStreak > 0 && (
                        <div className="flex items-center text-orange-400">
                            <FireIcon className="w-5 h-5 mr-1"/>
                            <span className="font-bold text-sm">{chat.blazeStreak}</span>
                        </div>
                    )}
                </div>
                <p className="text-sm text-gray-400 truncate">{lastMessageText}</p>
                {chat.lastMessage && <p className="text-xs text-gray-500">{new Date(chat.lastMessage.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>}
            </div>
        </div>
    );
};


export const FriendsView: React.FC<FriendsViewProps> = ({ currentUser, onNavigate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'chats' | 'friends' | 'requests'>('chats');
  const [isAddFriendModalOpen, setIsAddFriendModalOpen] = useState(false);

  // Mock data filtering
  const friends = MOCK_USERS.filter(u => currentUser.friends.includes(u.id) && u.username.toLowerCase().includes(searchTerm.toLowerCase()));
  const friendRequests = MOCK_USERS.filter(u => currentUser.friendRequests.includes(u.id));
  const chats = MOCK_CHATS.filter(chat => 
      chat.participants.some(p => p.id === currentUser.id) &&
      (chat.participants.find(p => p.id !== currentUser.id)?.username.toLowerCase().includes(searchTerm.toLowerCase()) || searchTerm === '')
  );

  const handleOpenChat = (chatId: string) => {
    onNavigate(AppScreen.CHAT_DETAIL, { chatId });
  };

  const handleAddFriend = (username: string) => {
    alert(`Friend request sent to ${username} (mocked).`);
    setIsAddFriendModalOpen(false);
  }

  return (
    <div className="h-full flex flex-col bg-gray-900 text-white p-4 pt-10 pb-20 overflow-y-auto">
      <header className="mb-6">
        <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-teal-400">Friends</h1>
            <Button variant="ghost" size="sm" onClick={() => setIsAddFriendModalOpen(true)} leftIcon={<PlusCircleIcon className="w-5 h-5"/>}>
                Add Friend
            </Button>
        </div>
        <div className="mt-4">
            <Input 
                type="text"
                placeholder="Search friends or chats..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-gray-800 border-gray-700"
            />
        </div>
      </header>

      <div className="flex border-b border-gray-700 mb-4">
        {['chats', 'friends', 'requests'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`py-2 px-4 font-medium capitalize transition-colors ${activeTab === tab ? 'text-pink-400 border-b-2 border-pink-400' : 'text-gray-400 hover:text-white'}`}
          >
            {tab} {tab === 'requests' && friendRequests.length > 0 && `(${friendRequests.length})`}
          </button>
        ))}
      </div>
      
      {activeTab === 'chats' && (
        <div>
          {chats.length > 0 ? chats.map(chat => (
            <ChatListItem key={chat.id} chat={chat} currentUser={currentUser} onOpenChat={handleOpenChat} />
          )) : <p className="text-gray-500 text-center py-8">No active chats. Start a new conversation!</p>}
        </div>
      )}

      {activeTab === 'friends' && (
        <div>
          {friends.length > 0 ? friends.map(friend => (
            <FriendCard 
                key={friend.id} 
                user={friend} 
                onChat={() => {
                    const existingChat = MOCK_CHATS.find(c => c.participants.some(p => p.id === friend.id) && c.participants.some(p => p.id === currentUser.id));
                    if (existingChat) {
                        handleOpenChat(existingChat.id);
                    } else {
                        // Mock creating a new chat
                        const newChatId = `chat-${currentUser.id}-${friend.id}`;
                        MOCK_CHATS.push({
                            id: newChatId,
                            participants: [currentUser, friend],
                            messages: [],
                            blazeStreak: 0,
                        });
                        handleOpenChat(newChatId);
                    }
                }}
                blazeScore={friend.blazeScore}
            />
          )) : <p className="text-gray-500 text-center py-8">No friends yet. Add some!</p>}
        </div>
      )}

      {activeTab === 'requests' && (
         <div>
          {friendRequests.length > 0 ? friendRequests.map(user => (
            <div key={user.id} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg mb-2">
                <div className="flex items-center">
                    <img src={user.avatarUrl || DEFAULT_AVATAR} alt={user.username} className="w-10 h-10 rounded-full mr-3"/>
                    <span className="font-medium">{user.username}</span>
                </div>
                <div className="space-x-2">
                    <Button size="sm" variant="primary" onClick={() => alert(`Accepted ${user.username}'s request (mocked)`)}>Accept</Button>
                    <Button size="sm" variant="secondary" onClick={() => alert(`Declined ${user.username}'s request (mocked)`)}>Decline</Button>
                </div>
            </div>
          )) : <p className="text-gray-500 text-center py-8">No new friend requests.</p>}
        </div>
      )}

      <Modal isOpen={isAddFriendModalOpen} onClose={() => setIsAddFriendModalOpen(false)} title="Add Friend">
        <form onSubmit={(e) => { e.preventDefault(); handleAddFriend((e.target as any).username.value); }}>
            <Input name="username" label="Username" placeholder="Enter friend's username" required />
            <Button type="submit" fullWidth className="mt-4">Send Request</Button>
        </form>
      </Modal>
    </div>
  );
};

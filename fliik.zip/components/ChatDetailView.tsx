
import React, { useState, useEffect, useRef } from 'react';
import { Chat, Message, User, MediaItem, AppScreen } from '../../types';
import { MOCK_CHATS, MOCK_USERS, ArrowLeftIcon, PaperAirplaneIcon, FireIcon, DEFAULT_AVATAR } from '../../constants';
import { Button } from './ui/Button';
import { Input } from './ui/Input';

interface ChatDetailViewProps {
  chatId: string;
  currentUser: User;
  onBack: () => void;
  onViewProfile: (userId: string) => void; // For tapping on user avatar in chat
}

const ChatMessageBubble: React.FC<{ message: Message; isSender: boolean; senderUser?: User }> = ({ message, isSender, senderUser }) => {
  const [mediaSeen, setMediaSeen] = useState(message.seen);

  const handleMediaView = () => {
    if (typeof message.content !== 'string' && message.disappears && !mediaSeen) {
      setMediaSeen(true); // Simulate disappearing after one view
      // In a real app, this would also update backend
    }
  };

  const bubbleClass = isSender
    ? 'bg-gradient-to-r from-purple-600 to-pink-600 self-end rounded-l-xl rounded-tr-xl'
    : 'bg-gray-700 self-start rounded-r-xl rounded-tl-xl';
  
  const mediaContent = typeof message.content !== 'string' ? message.content as MediaItem : null;

  if (mediaContent && message.disappears && mediaSeen && !isSender) { // Content viewed by receiver
    return (
        <div className={`p-3 my-1 max-w-xs md:max-w-md text-sm ${bubbleClass} text-gray-400 italic`}>
            Fliik opened by you.
        </div>
    );
  }
  if (mediaContent && message.disappears && message.seen && isSender) { // Content viewed by receiver, sender sees status
     return (
        <div className={`p-3 my-1 max-w-xs md:max-w-md text-sm ${bubbleClass} text-gray-400 italic`}>
            Fliik opened.
        </div>
    );
  }


  return (
    <div className={`flex items-end space-x-2 my-2 ${isSender ? 'justify-end' : ''}`}>
        {!isSender && senderUser && (
            <img src={senderUser.avatarUrl || DEFAULT_AVATAR} alt={senderUser.username} className="w-8 h-8 rounded-full self-start" />
        )}
        <div className={`p-3 my-1 max-w-xs md:max-w-md text-sm ${bubbleClass} shadow-md`}>
        {typeof message.content === 'string' ? (
            <p>{message.content}</p>
        ) : (
            <div onClick={handleMediaView} className="cursor-pointer">
            {mediaContent?.type === 'photo' ? (
                <img src={mediaContent.url} alt="Fliik media" className="rounded-md max-h-60" />
            ) : (
                <video src={mediaContent.url} controls className="rounded-md max-h-60"></video>
            )}
            {!mediaSeen && message.disappears && <p className="text-xs text-center text-gray-300 mt-1">Tap to view</p>}
            </div>
        )}
        <p className={`text-xs mt-1 ${isSender ? 'text-purple-200' : 'text-gray-400'} text-opacity-80`}>
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
        </div>
    </div>
  );
};


export const ChatDetailView: React.FC<ChatDetailViewProps> = ({ chatId, currentUser, onBack, onViewProfile }) => {
  const [chat, setChat] = useState<Chat | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Find chat from MOCK_CHATS or fetch from API
    const currentChat = MOCK_CHATS.find(c => c.id === chatId);
    if (currentChat) {
        // Mark messages as seen (mock)
        currentChat.messages.forEach(msg => {
            if (msg.receiverId === currentUser.id && !msg.seen) msg.seen = true;
        });
        setChat(currentChat);
    }
  }, [chatId, currentUser.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chat?.messages]);

  const handleSendMessage = () => {
    if (newMessage.trim() === '' || !chat) return;
    const otherParticipant = chat.participants.find(p => p.id !== currentUser.id);
    if (!otherParticipant) return;

    const message: Message = {
      id: `msg-${Date.now()}`,
      chatId: chat.id,
      senderId: currentUser.id,
      receiverId: otherParticipant.id,
      content: newMessage,
      timestamp: Date.now(),
      seen: false,
      disappears: false,
    };
    // Update MOCK_CHATS (in real app, send to backend)
    const chatIndex = MOCK_CHATS.findIndex(c => c.id === chat.id);
    if (chatIndex !== -1) {
      MOCK_CHATS[chatIndex].messages.push(message);
      MOCK_CHATS[chatIndex].lastMessage = message; // Update last message for chat list
      setChat({ ...MOCK_CHATS[chatIndex] }); // Trigger re-render
    }
    setNewMessage('');
  };

  if (!chat) return <div className="p-4 text-center">Loading chat...</div>;

  const otherParticipant = chat.participants.find(p => p.id !== currentUser.id) || chat.participants[0];
  
  return (
    <div className="h-full flex flex-col bg-gray-900 text-white">
      {/* Header */}
      <header className="flex items-center p-3 border-b border-gray-700 bg-gray-800/80 backdrop-blur-md sticky top-0 z-10">
        <Button variant="ghost" size="sm" onClick={onBack} className="mr-2 !p-2">
          <ArrowLeftIcon className="w-6 h-6" />
        </Button>
        <img 
            src={otherParticipant.avatarUrl || DEFAULT_AVATAR} 
            alt={otherParticipant.username} 
            className="w-10 h-10 rounded-full mr-3 cursor-pointer"
            onClick={() => onViewProfile(otherParticipant.id)}
        />
        <div className="flex-1">
          <h2 className="font-semibold text-lg">{otherParticipant.username}</h2>
          <p className="text-xs text-gray-400">{otherParticipant.onlineStatus ? 'Online' : 'Offline'}</p>
        </div>
        <div className="flex items-center text-orange-400">
          <FireIcon className="w-5 h-5 mr-1" />
          <span className="font-bold">{chat.blazeStreak}</span>
        </div>
      </header>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2 pb-4">
        {chat.messages.map(msg => {
            const sender = MOCK_USERS.find(u => u.id === msg.senderId);
            return <ChatMessageBubble key={msg.id} message={msg} isSender={msg.senderId === currentUser.id} senderUser={sender} />;
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 border-t border-gray-700 bg-gray-800/80 backdrop-blur-md sticky bottom-0">
        <div className="flex items-center space-x-2">
            {/* Add buttons for sending photos, voice notes, etc. */}
            <Button variant="ghost" size="sm" className="!p-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-pink-400">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316zM16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0zM18.75 10.5h.008v.008h-.008V10.5z" />
                </svg>
            </Button>
          <Input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Send a Fliik..."
            className="flex-1 bg-gray-700 border-gray-600 !py-2.5"
          />
          <Button onClick={handleSendMessage} size="sm" className="!p-2.5 bg-pink-500 hover:bg-pink-600">
            <PaperAirplaneIcon className="w-6 h-6 text-white" />
          </Button>
        </div>
      </div>
    </div>
  );
};

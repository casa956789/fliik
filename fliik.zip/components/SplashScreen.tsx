
import React from 'react';
import { APP_NAME, APP_TAGLINE, SparklesIcon } from '../../constants';

export const SplashScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-purple-900 via-black to-teal-900 text-white p-4">
      <div className="text-center animate-fadeIn">
        <SparklesIcon className="w-24 h-24 text-pink-400 mx-auto mb-6 animate-pulse" />
        <h1 className="text-6xl font-bold" style={{ fontFamily: "'Pacifico', cursive" }}>{APP_NAME}</h1>
        <p className="mt-3 text-xl text-gray-300">{APP_TAGLINE}</p>
      </div>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn { animation: fadeIn 1s ease-out forwards; }
        .animate-pulse { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.1); }
        }
      `}</style>
    </div>
  );
};

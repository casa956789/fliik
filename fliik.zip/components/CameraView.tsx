
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { CapturedMedia, MediaFilter, AppScreen } from '../../types';
import { Button } from './ui/Button';
import { SunIcon, XMarkIcon, UserCircleIcon, SparklesIcon } from '../../constants'; // Assuming XMarkIcon is for closing preview

interface CameraViewProps {
  onMediaCaptured: (media: CapturedMedia) => void;
  setCurrentScreen: (screen: AppScreen) => void; // To navigate to preview or other states if needed directly from camera
}

const FilterButton: React.FC<{filterName: MediaFilter, currentFilter: MediaFilter, setFilter: (filter: MediaFilter) => void, children: React.ReactNode}> = ({filterName, currentFilter, setFilter, children}) => (
    <button 
        onClick={() => setFilter(filterName)}
        className={`p-2 rounded-full transition-all ${currentFilter === filterName ? 'bg-pink-500 ring-2 ring-white' : 'bg-black/50 hover:bg-white/30'}`}
    >
        {children}
    </button>
);

export const CameraView: React.FC<CameraViewProps> = ({ onMediaCaptured, setCurrentScreen }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedMediaFile, setCapturedMediaFile] = useState<File | null>(null);
  const [mediaPreviewUrl, setMediaPreviewUrl] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'photo' | 'video'>('photo');
  const [currentFilter, setCurrentFilter] = useState<MediaFilter>('none');
  const [textOverlay, setTextOverlay] = useState('');

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filterClasses: Record<MediaFilter, string> = {
    none: '',
    grayscale: 'filter grayscale',
    blur: 'filter blur-sm',
    brightness: 'filter brightness-150',
  };

  const startCamera = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: true });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      alert("Could not access camera. Please ensure permissions are granted and try the file picker.");
    }
  }, []);

  useEffect(() => {
    startCamera();
    return () => {
      stream?.getTracks().forEach(track => track.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startCamera]);


  const handleCapture = () => {
    if (fileInputRef.current) {
        fileInputRef.current.accept = "image/*"; // Ensure it defaults to image for tap
        fileInputRef.current.click(); // Trigger file input for web environment
    }
  };
  
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCapturedMediaFile(file);
      const url = URL.createObjectURL(file);
      setMediaPreviewUrl(url);
      setMediaType(file.type.startsWith('image/') ? 'photo' : 'video');
    }
  };

  const handleSend = () => {
    if (mediaPreviewUrl && capturedMediaFile) {
        // In a real app, this file would be uploaded.
        // For mock, we use the object URL directly.
      onMediaCaptured({
        id: Date.now().toString(),
        url: mediaPreviewUrl, // This is a blob URL, will work locally
        type: mediaType,
        filter: currentFilter,
        textOverlay: textOverlay,
      });
      // setCurrentScreen(AppScreen.SEND_TO); // Redundant: onMediaCaptured in App.tsx handles this navigation
      // Reset state for next capture
      setMediaPreviewUrl(null);
      setCapturedMediaFile(null);
      setTextOverlay('');
      setCurrentFilter('none');
    }
  };
  
  // Simulate recording by just setting a flag
  const handleRecord = () => {
    if (!isRecording) {
        setIsRecording(true);
        // Simulate recording for 3 seconds then auto-trigger file select for video
        setTimeout(() => {
            setIsRecording(false);
            if(fileInputRef.current) {
                fileInputRef.current.accept = "video/*";
                fileInputRef.current.click();
            }
        }, 3000);
    }
  };

  if (mediaPreviewUrl) {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-50 p-4">
        <div className={`relative w-full max-w-lg aspect-[9/16] rounded-lg overflow-hidden ${filterClasses[currentFilter]}`}>
          {mediaType === 'photo' ? (
            <img src={mediaPreviewUrl} alt="Preview" className="w-full h-full object-cover" />
          ) : (
            <video src={mediaPreviewUrl} controls autoPlay loop className="w-full h-full object-cover"></video>
          )}
          {textOverlay && (
            <div className="absolute inset-x-0 bottom-1/4 p-4 text-center">
              <p className="text-white text-2xl font-bold" style={{textShadow: '2px 2px 4px rgba(0,0,0,0.7)'}}>{textOverlay}</p>
            </div>
          )}
        </div>
        
        <input 
            type="text"
            value={textOverlay}
            onChange={(e) => setTextOverlay(e.target.value)}
            placeholder="Add text..."
            className="my-4 p-2 rounded bg-gray-800 text-white w-full max-w-lg"
            aria-label="Add text overlay"
        />

        <div className="flex space-x-2 my-4" role="toolbar" aria-label="Media filters">
            <FilterButton filterName="none" currentFilter={currentFilter} setFilter={setCurrentFilter}><span className="text-xs">None</span></FilterButton>
            <FilterButton filterName="grayscale" currentFilter={currentFilter} setFilter={setCurrentFilter}><span className="text-xs">Grayscale</span></FilterButton>
            <FilterButton filterName="blur" currentFilter={currentFilter} setFilter={setCurrentFilter}><span className="text-xs">Blur</span></FilterButton>
            <FilterButton filterName="brightness" currentFilter={currentFilter} setFilter={setCurrentFilter}><SunIcon className="w-4 h-4" aria-hidden="true" /><span className="sr-only">Brightness</span></FilterButton>
        </div>

        <div className="flex justify-around w-full max-w-lg mt-4">
          <Button onClick={() => { setMediaPreviewUrl(null); setTextOverlay(''); setCurrentFilter('none'); }} variant="secondary" aria-label="Retake media">
            <XMarkIcon className="w-5 h-5 mr-1" aria-hidden="true" /> Retake
          </Button>
          <Button onClick={handleSend} variant="primary" aria-label="Send media">Send To</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col items-center justify-between bg-black text-white p-4 pt-10">
      <div className="w-full flex justify-between items-center">
        <button className="p-2 rounded-full bg-white/10 hover:bg-white/20" aria-label="Open profile settings">
            <UserCircleIcon className="w-6 h-6 text-white"/>
        </button>
        <button className="p-2 rounded-full bg-white/10 hover:bg-white/20" aria-label="Toggle flash">
            <SunIcon className="w-6 h-6 text-white"/>
        </button>
      </div>

      <div className="relative w-full aspect-[9/16] max-w-lg bg-gray-800 rounded-lg overflow-hidden my-4">
        {stream ? (
          <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" aria-label="Camera feed"></video>
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-500">Camera Loading...</div>
        )}
        <canvas ref={canvasRef} className="hidden" aria-hidden="true"></canvas>
      </div>
      
      <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*,video/*" className="hidden" capture="environment" aria-label="Upload media file" />

      <div className="flex flex-col items-center space-y-4">
        <div className="flex items-center space-x-8">
            <button className="p-2 rounded-full bg-white/10 hover:bg-white/20" aria-label="Open effects"> 
                <SparklesIcon className="w-7 h-7 text-white" />
            </button>
            <button
                onClick={handleCapture} 
                aria-label="Tap to capture photo, or use file picker"
                className={`w-20 h-20 rounded-full border-4 border-white flex items-center justify-center transition-transform duration-200
                            ${isRecording ? 'bg-red-500 animate-pulse scale-110' : 'bg-white/30 hover:bg-white/50'}`}
                >
            </button>
            <button className="p-2 rounded-full bg-white/10 hover:bg-white/20" aria-label="Flip camera"> 
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-7 h-7 text-white" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
                </svg>
            </button>
        </div>
         <Button onClick={handleRecord} variant="secondary" className="mt-2" aria-label="Hold for video (simulated 3 second recording then file pick)">
            {isRecording ? "Recording..." : "Hold for Video (Simulated)"}
        </Button>
      </div>
    </div>
  );
};


import React, { useState } from 'react';
import { User, CapturedMedia, AppScreen } from '../../types';
import { MOCK_USERS, DEFAULT_AVATAR, ArrowLeftIcon, StoryIcon, PaperAirplaneIcon } from '../../constants';
import { Button } from './ui/Button';
import { Input } from './ui/Input';

interface MediaSendToScreenProps {
  currentUser: User;
  media: CapturedMedia;
  onSend: (media: CapturedMedia, recipientIds: string[], isStory: boolean) => void;
  onBack: () => void; // Go back to media preview
}

export const MediaSendToScreen: React.FC<MediaSendToScreenProps> = ({ currentUser, media, onSend, onBack }) => {
  const [selectedFriends, setSelectedFriends] = useState<Set<string>>(new Set());
  const [sendToMyStory, setSendToMyStory] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const friends = MOCK_USERS.filter(u => currentUser.friends.includes(u.id) && u.username.toLowerCase().includes(searchTerm.toLowerCase()));

  const toggleFriendSelection = (friendId: string) => {
    setSelectedFriends(prev => {
      const newSet = new Set(prev);
      if (newSet.has(friendId)) {
        newSet.delete(friendId);
      } else {
        newSet.add(friendId);
      }
      return newSet;
    });
  };

  const handleSend = () => {
    if (selectedFriends.size === 0 && !sendToMyStory) {
      alert("Please select at least one recipient or your story.");
      return;
    }
    onSend(media, Array.from(selectedFriends), sendToMyStory);
  };

  return (
    <div className="fixed inset-0 bg-gray-900 flex flex-col z-50 text-white">
      <header className="flex items-center p-4 border-b border-gray-700 bg-gray-800/80 backdrop-blur-md">
        <Button variant="ghost" size="sm" onClick={onBack} className="mr-2 !p-2">
          <ArrowLeftIcon className="w-6 h-6" />
        </Button>
        <h2 className="text-xl font-semibold flex-1 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-teal-400">Send To...</h2>
        {/* Placeholder for group creation icon */}
        <div className="w-10"></div> 
      </header>

      <div className="p-4">
        <Input 
            type="text" 
            placeholder="Search friends..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-gray-800 border-gray-700"
        />
      </div>

      <div className="flex-1 overflow-y-auto px-4">
        {/* My Story Option */}
        <div 
            className={`flex items-center p-3 rounded-lg cursor-pointer mb-3 transition-all ${sendToMyStory ? 'bg-pink-500/30 border border-pink-500' : 'bg-gray-800/60 hover:bg-gray-700/80'}`}
            onClick={() => setSendToMyStory(!sendToMyStory)}
        >
            <div className="p-2 bg-gradient-to-br from-purple-500 to-teal-500 rounded-full mr-3">
                <StoryIcon className="w-7 h-7 text-white" />
            </div>
            <span className="font-semibold text-lg flex-1">My Story</span>
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${sendToMyStory ? 'bg-pink-500 border-pink-500' : 'border-gray-500'}`}>
                {sendToMyStory && <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 text-white"><path fillRule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clipRule="evenodd" /></svg>}
            </div>
        </div>

        <h3 className="text-gray-400 text-sm font-semibold my-3">Friends</h3>
        {friends.length > 0 ? friends.map(friend => (
          <div 
            key={friend.id}
            className={`flex items-center p-3 rounded-lg cursor-pointer mb-2 transition-all ${selectedFriends.has(friend.id) ? 'bg-pink-500/30 border border-pink-500' : 'bg-gray-800/60 hover:bg-gray-700/80'}`}
            onClick={() => toggleFriendSelection(friend.id)}
          >
            <img src={friend.avatarUrl || DEFAULT_AVATAR} alt={friend.username} className="w-10 h-10 rounded-full mr-3"/>
            <span className="font-medium flex-1">{friend.username}</span>
            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${selectedFriends.has(friend.id) ? 'bg-pink-500 border-pink-500' : 'border-gray-500'}`}>
                {selectedFriends.has(friend.id) && <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 text-white"><path fillRule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clipRule="evenodd" /></svg>}
            </div>
          </div>
        )) : <p className="text-gray-500 text-center py-4">No friends match your search.</p>}
      </div>

      <div className="p-4 border-t border-gray-700">
        <Button 
          onClick={handleSend} 
          fullWidth 
          size="lg"
          disabled={selectedFriends.size === 0 && !sendToMyStory}
          leftIcon={<PaperAirplaneIcon className="w-6 h-6"/>}
        >
          Send ({selectedFriends.size + (sendToMyStory ? 1 : 0)})
        </Button>
      </div>
    </div>
  );
};


import React, { useState, useEffect, useCallback } from 'react';
import { User, AppScreen, CapturedMedia, Chat, Story, MediaItem, Message } from './types';
import { SplashScreen } from './components/SplashScreen';
import { AuthScreen } from './components/AuthScreen';
import { CameraView } from './components/CameraView';
import { FriendsView } from './components/FriendsView';
import { StoriesView } from './components/StoriesView';
import { VaultView } from './components/VaultView';
import { ProfileView } from './components/ProfileView';
import { BottomNav } from './components/ui/BottomNav';
import { MOCK_USERS, MOCK_CHATS, MOCK_STORIES } from './constants';
import { ChatDetailView } from './components/ChatDetailView';
import { MediaSendToScreen } from './components/MediaSendToScreen';


const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>(AppScreen.SPLASH);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoadingSplash, setIsLoadingSplash] = useState(true);
  
  // Specific view states
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [capturedMediaForSend, setCapturedMediaForSend] = useState<CapturedMedia | null>(null);

  useEffect(() => {
    // Simulate splash screen duration
    const timer = setTimeout(() => {
      setIsLoadingSplash(false);
      // Check for saved user session (mock with localStorage)
      const savedUser = localStorage.getItem('fliikUser');
      if (savedUser) {
        setCurrentUser(JSON.parse(savedUser));
        setCurrentScreen(AppScreen.CAMERA); // Default to camera after login
      } else {
        setCurrentScreen(AppScreen.AUTH);
      }
    }, 2500); // Splash screen for 2.5 seconds
    return () => clearTimeout(timer);
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('fliikUser', JSON.stringify(user)); // Mock session save
    setCurrentScreen(AppScreen.CAMERA);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('fliikUser'); // Mock session clear
    setCurrentScreen(AppScreen.AUTH);
  };

  const handleNavigate = useCallback((screen: AppScreen, params?: any) => {
    if (screen === AppScreen.CHAT_DETAIL && params?.chatId) {
      setActiveChatId(params.chatId);
    } else {
      setActiveChatId(null); // Clear active chat if navigating elsewhere
    }
    if (screen === AppScreen.SEND_TO && params?.media) {
      setCapturedMediaForSend(params.media);
    } else if (screen !== AppScreen.MEDIA_PREVIEW) { // Don't clear if going to preview
        setCapturedMediaForSend(null);
    }
    setCurrentScreen(screen);
  }, []);

  const handleMediaCaptured = (media: CapturedMedia) => {
    setCapturedMediaForSend(media);
    setCurrentScreen(AppScreen.SEND_TO); // Navigate to SendTo screen after capture
  };

  const handleSendMedia = (media: CapturedMedia, recipientIds: string[], isStory: boolean) => {
    console.log("Sending media:", media, "to recipients:", recipientIds, "as story:", isStory);
    // Mock sending:
    if (isStory && currentUser) {
        const newStorySegment: MediaItem = { ...media }; // Ensure it's treated as MediaItem
        const existingStoryIndex = MOCK_STORIES.findIndex(s => s.userId === currentUser.id);
        if (existingStoryIndex > -1) {
            MOCK_STORIES[existingStoryIndex].media.push(newStorySegment);
            MOCK_STORIES[existingStoryIndex].timestamp = Date.now();
            MOCK_STORIES[existingStoryIndex].expiresAt = Date.now() + 24 * 60 * 60 * 1000;
        } else {
            MOCK_STORIES.push({
                id: `story-${Date.now()}`,
                userId: currentUser.id,
                username: currentUser.username,
                userAvatar: currentUser.avatarUrl,
                media: [newStorySegment],
                timestamp: Date.now(),
                expiresAt: Date.now() + 24 * 60 * 60 * 1000,
                viewers: []
            });
        }
        alert("Fliik added to your story! (mocked)");
    }

    recipientIds.forEach(recipientId => {
        // Find or create chat with recipient
        let chat = MOCK_CHATS.find(c => 
            c.participants.some(p => p.id === currentUser?.id) &&
            c.participants.some(p => p.id === recipientId)
        );
        if (!chat && currentUser) {
            const recipientUser = MOCK_USERS.find(u => u.id === recipientId);
            if (recipientUser) {
                chat = {
                    id: `chat-${currentUser.id}-${recipientId}-${Date.now()}`,
                    participants: [currentUser, recipientUser],
                    messages: [],
                    blazeStreak: 0 // Initialize streak
                };
                MOCK_CHATS.push(chat);
            }
        }

        if (chat && currentUser) {
            const newMessage: Message = { // Ensure it's treated as Message
                id: `msg-${Date.now()}`,
                chatId: chat.id,
                senderId: currentUser.id,
                receiverId: recipientId,
                content: media,
                timestamp: Date.now(),
                seen: false,
                disappears: true // Media sent directly usually disappears
            };
            chat.messages.push(newMessage);
            chat.lastMessage = newMessage;
            // Mock blaze streak increment
            chat.blazeStreak = (chat.blazeStreak || 0) + 1; 
            alert(`Fliik sent to ${MOCK_USERS.find(u=>u.id === recipientId)?.username}! (mocked)`);
        }
    });
    
    setCapturedMediaForSend(null);
    setCurrentScreen(AppScreen.CAMERA); // Go back to camera after sending
  };


  if (isLoadingSplash) {
    return <SplashScreen />;
  }

  if (!currentUser || currentScreen === AppScreen.AUTH) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  // Main App Content
  let ScreenComponent;
  switch (currentScreen) {
    case AppScreen.CAMERA:
      ScreenComponent = <CameraView onMediaCaptured={handleMediaCaptured} setCurrentScreen={setCurrentScreen} />;
      break;
    case AppScreen.FRIENDS:
      ScreenComponent = <FriendsView currentUser={currentUser} onNavigate={handleNavigate} />;
      break;
    case AppScreen.STORIES:
      ScreenComponent = <StoriesView currentUser={currentUser} onViewStory={() => {}} onNavigate={handleNavigate} />;
      break;
    case AppScreen.VAULT:
      ScreenComponent = <VaultView currentUser={currentUser} />;
      break;
    case AppScreen.PROFILE:
      ScreenComponent = <ProfileView currentUser={currentUser} onLogout={handleLogout} onNavigate={handleNavigate} />;
      break;
    case AppScreen.CHAT_DETAIL:
      if (activeChatId) {
        ScreenComponent = <ChatDetailView chatId={activeChatId} currentUser={currentUser} onBack={() => handleNavigate(AppScreen.FRIENDS)} onViewProfile={(userId) => { /* Navigate to user's profile, simple alert for now */ alert(`View profile of ${userId}`); }}/>;
      } else {
        ScreenComponent = <FriendsView currentUser={currentUser} onNavigate={handleNavigate} />; // Fallback
      }
      break;
    case AppScreen.MEDIA_PREVIEW: // This state is handled within CameraView for simplicity now
       ScreenComponent = <CameraView onMediaCaptured={handleMediaCaptured} setCurrentScreen={setCurrentScreen} />;
       break;
    case AppScreen.SEND_TO:
      if (capturedMediaForSend) {
        ScreenComponent = <MediaSendToScreen currentUser={currentUser} media={capturedMediaForSend} onSend={handleSendMedia} onBack={() => { setCapturedMediaForSend(null); setCurrentScreen(AppScreen.CAMERA); /* Or AppScreen.MEDIA_PREVIEW if that was a distinct step */ }} />;
      } else {
        ScreenComponent = <CameraView onMediaCaptured={handleMediaCaptured} setCurrentScreen={setCurrentScreen} />; // Fallback
      }
      break;
    default:
      ScreenComponent = <CameraView onMediaCaptured={handleMediaCaptured} setCurrentScreen={setCurrentScreen} />;
  }
  
  // Screens that should not show bottom nav
  const noNavScreens: AppScreen[] = [AppScreen.CHAT_DETAIL, AppScreen.SEND_TO, AppScreen.SPLASH, AppScreen.AUTH];


  return (
    <div className="h-screen w-screen overflow-hidden flex flex-col bg-black">
      <main className="flex-1 overflow-y-auto overflow-x-hidden">
        {ScreenComponent}
      </main>
      {!noNavScreens.includes(currentScreen) && (
        <BottomNav activeScreen={currentScreen} onNavigate={handleNavigate} />
      )}
    </div>
  );
};

export default App;


import { User, Chat, Story } from './types';

export const APP_NAME = "Fliik";
export const APP_TAGLINE = "Shoot it. Fliik it.";

export const ICON_SIZE = "h-7 w-7";
export const SMALL_ICON_SIZE = "h-5 w-5";

export const CameraIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0zM18.75 10.5h.008v.008h-.008V10.5z" />
  </svg>
);

export const UsersIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-3.741-5.192M15 15a3 3 0 11-6 0 3 3 0 016 0zm6 3a9 9 0 11-18 0 9 9 0 0118 0zM12.75 5.106a8.9501 8.9501 0 00-5.402-1.5A8.995 8.995 0 001.5 12c0 1.85.528 3.562 1.442 5.004M12.75 5.106a8.923 8.923 0 015.402-1.5 8.995 8.995 0 015.858 12.981" />
  </svg>
);

export const StoryIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
  </svg>
);

export const LockClosedIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
  </svg>
);

export const UserCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export const SparklesIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12L17 14.846l-1.25-2.846a4.5 4.5 0 00-3.09-3.09L9.75 8l2.846-1.25a4.5 4.5 0 003.09-3.09L17 1.154l1.25 2.846a4.5 4.5 0 003.09 3.09L24.25 8l-2.846 1.25a4.5 4.5 0 00-3.09 3.09z" />
  </svg>
);

export const ChatBubbleLeftRightIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3.697-3.697C16.126 14.85 15.015 15 14.004 15H10.5a2.25 2.25 0 01-2.25-2.25V7.512c0-.369.02-.733.057-1.093H4.5a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 21h7.516c.369.02.733.057 1.093.093l4.078 4.078a.75.75 0 001.326-.316V19.921c1.334-.33 2.305-1.403 2.493-2.731.02-.135.037-.27.053-.407v-4.286c0-.97-.616-1.813-1.5-2.097zM9.75 10.875c0 .414.168.75.375.75h4.5a.375.375 0 00.375-.375V9.375a.375.375 0 00-.375-.375h-4.5a.375.375 0 00-.375.375v1.5z" />
    </svg>
);

export const FireIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.362 5.214A8.252 8.252 0 0112 21 8.25 8.25 0 016.038 7.048 8.287 8.287 0 009 9.6c.001.03.003.06.003.091l.003-3.72a8.25 8.25 0 013.06-2.063M16.5 18.75h-9a2.25 2.25 0 010-4.5h9a2.25 2.25 0 010 4.5z" />
  </svg>
);

export const ArrowLeftIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
  </svg>
);

export const PaperAirplaneIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
  </svg>
);

export const PlusCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v6m3-3H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export const XMarkIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

export const SunIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-6.364-.386l1.591-1.591M3 12h2.25m.386-6.364l1.591 1.591M12 12a2.25 2.25 0 00-2.25 2.25 2.25 2.25 0 002.25 2.25s2.25 0 2.25-2.25A2.25 2.25 0 0012 12z" />
  </svg>
);

export const EyeIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export const CheckCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const LogoutIcon = (props: React.SVGProps<SVGSVGElement>) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" {...props}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
</svg>
);


export const DEFAULT_AVATAR = 'https://picsum.photos/seed/defaultavatar/200/200';

export const MOCK_USERS: User[] = [
  { id: 'user1', username: 'NeonNinja', avatarUrl: 'https://picsum.photos/seed/user1/200/200', blazeScore: 1250, onlineStatus: true, friends: ['user2', 'user3'], friendRequests: [] , bio: 'Riding the synthwave 🌊'},
  { id: 'user2', username: 'SynthwaveSurfer', avatarUrl: 'https://picsum.photos/seed/user2/200/200', blazeScore: 880, onlineStatus: false, friends: ['user1'], friendRequests: ['user4'] , bio: 'Chasing sunsets & pixels ✨'},
  { id: 'user3', username: 'GlitchPop', avatarUrl: 'https://picsum.photos/seed/user3/200/200', blazeScore: 2400, onlineStatus: true, friends: ['user1'], friendRequests: [] , bio: 'Life is a mixtape 📼'},
  { id: 'user4', username: 'RetroRewind', avatarUrl: 'https://picsum.photos/seed/user4/200/200', blazeScore: 500, onlineStatus: false, friends: [], friendRequests: [] , bio: '80s baby in a 20s world'},
];

export const MOCK_CHAT_ID_USER2 = 'chat1-2';

export const MOCK_CHATS: Chat[] = [
  {
    id: MOCK_CHAT_ID_USER2,
    participants: [MOCK_USERS[0], MOCK_USERS[1]],
    messages: [
      { id: 'msg1', chatId: MOCK_CHAT_ID_USER2, senderId: 'user1', receiverId: 'user2', content: 'Hey! What’s up?', timestamp: Date.now() - 3600000, seen: true, disappears: false },
      { id: 'msg2', chatId: MOCK_CHAT_ID_USER2, senderId: 'user2', receiverId: 'user1', content: 'Not much, just chilling. You?', timestamp: Date.now() - 3500000, seen: true, disappears: false },
      { id: 'msg3', chatId: MOCK_CHAT_ID_USER2, senderId: 'user1', receiverId: 'user2', content: { id:'media1', type: 'photo', url: 'https://picsum.photos/seed/chatimg1/300/400', filter: 'none' }, timestamp: Date.now() - 3000000, seen: false, disappears: true },
    ],
    blazeStreak: 69,
    lastMessage: { id: 'msg3', chatId: MOCK_CHAT_ID_USER2, senderId: 'user1', receiverId: 'user2', content: { id:'media1', type: 'photo', url: 'https://picsum.photos/seed/chatimg1/300/400', filter: 'none' }, timestamp: Date.now() - 3000000, seen: false, disappears: true },
  },
  {
    id: 'chat1-3',
    participants: [MOCK_USERS[0], MOCK_USERS[2]],
    messages: [
      { id: 'msg4', chatId: 'chat1-3', senderId: 'user3', receiverId: 'user1', content: 'Check out this cool spot! 🌃', timestamp: Date.now() - 7200000, seen: true, disappears: false },
    ],
    blazeStreak: 12,
    lastMessage: { id: 'msg4', chatId: 'chat1-3', senderId: 'user3', receiverId: 'user1', content: 'Check out this cool spot! 🌃', timestamp: Date.now() - 7200000, seen: true, disappears: false },
  }
];

export const MOCK_STORIES: Story[] = [
  { id: 'story1', userId: 'user2', username: 'SynthwaveSurfer', userAvatar: MOCK_USERS[1].avatarUrl, media: [{id: 'smedia1', type: 'photo', url: 'https://picsum.photos/seed/story1/400/600'}], timestamp: Date.now() - 1000 * 60 * 60 * 3, expiresAt: Date.now() + 1000 * 60 * 60 * 21, viewers: ['user1'] },
  { id: 'story2', userId: 'user3', username: 'GlitchPop', userAvatar: MOCK_USERS[2].avatarUrl, media: [{id: 'smedia2', type: 'video', url: 'https://picsum.photos/seed/story2/400/600'}, {id: 'smedia3', type: 'photo', url: 'https://picsum.photos/seed/story3/400/600'}], timestamp: Date.now() - 1000 * 60 * 60 * 5, expiresAt: Date.now() + 1000 * 60 * 60 * 19, viewers: [] },
];
